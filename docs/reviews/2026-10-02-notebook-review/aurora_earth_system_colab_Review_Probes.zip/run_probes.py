"""Review probes for tutorials/aurora_earth_system_colab.ipynb (Notebook Review Framework v1, prefix AUR).

Run from the repository root:  python run_probes.py  (needs numpy + torch; no aurora package, no weights,
no network). Every model-dependent probe uses a STAND-IN: a fake `aurora` module and a one-parameter model
whose output is persistence + a trainable "lora" shift. The stand-in exercises the real carried
AuroraPipeline.adapt / evaluate / predict control flow, not Aurora's numerics.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import types
from dataclasses import dataclass
from pathlib import Path

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / "src"))
NB = ROOT / "tutorials" / "aurora_earth_system_colab.ipynb"
results: dict = {}


def record(key, value):
    results[key] = value
    print(key, json.dumps(value, default=str)[:400])


# ---- P1 source / static ------------------------------------------------------------------------------
raw = NB.read_bytes()
nb = json.loads(raw)
# git hash-object applies the checkout's eol normalisation (a Windows worktree may hold CRLF bytes)
blob = subprocess.run(["git", "hash-object", str(NB)], capture_output=True, text=True).stdout.strip()
code = [("".join(c["source"])) for c in nb["cells"] if c["cell_type"] == "code"]
compile_errors = []
for i, src in enumerate(code):
    try:
        compile(src, f"cell{i}", "exec")
    except SyntaxError as exc:
        compile_errors.append((i, str(exc)))
record("P1_static", {
    "nbformat": [nb["nbformat"], nb["nbformat_minor"]], "cells": len(nb["cells"]), "code_cells": len(code),
    "git_blob": blob, "evidenced_blob_prefix": "42fb3883", "blob_matches_evidence": blob.startswith("42fb3883"),
    "compile_errors": compile_errors, "declared_spec": nb["metadata"]["dimer"]["notebook_spec"],
    "profile": nb["metadata"]["dimer"]["notebook_profile"], "mode": nb["metadata"]["dimer"]["notebook_mode"],
    "outputs_persisted": sum(1 for c in nb["cells"] if c["cell_type"] == "code" and c.get("outputs")),
    "code_cells_with_cellView_form": sum(1 for c in nb["cells"] if c["cell_type"] == "code" and c.get("metadata", {}).get("cellView") == "form"),
    "carried_module_chars": sum(len(s) for s in code[1:4]),
})
gen = subprocess.run([sys.executable, "tools/build_notebook.py", "--check"], capture_output=True, text=True)
record("P1_generator_check", {"exit": gen.returncode, "stdout": gen.stdout.strip()[-200:]})
md = "\n".join("".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "markdown")
record("P1_guided_layer_keywords", {k: md.lower().count(k.lower()) for k in [
    "troubleshoot", "glossary", "check your reasoning", "predict", "what to notice", "infrastructure",
    "how to use this notebook", "roadmap", "overlap", "pretraining"]})

# ---- fake aurora (stand-in) --------------------------------------------------------------------------
import numpy as np  # noqa: E402
import torch  # noqa: E402


@dataclass
class Metadata:
    lat: object
    lon: object
    time: tuple
    atmos_levels: tuple


@dataclass
class Batch:
    surf_vars: dict
    static_vars: dict
    atmos_vars: dict
    metadata: Metadata

    def to(self, device):
        return self


class StandIn(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.lora_shift = torch.nn.Parameter(torch.zeros(()))

    def forward(self, batch):
        h = batch.surf_vars["2t"].shape[-2]
        h4 = h - h % 4
        scale = {"2t": 10.0, "10u": 5.0, "10v": 5.0, "msl": 1000.0, "t": 10.0, "u": 15.0, "v": 15.0, "q": 4e-3, "z": 25000.0}
        surf = {k: v[:, -1:, :h4] + self.lora_shift * scale[k] for k, v in batch.surf_vars.items()}
        atmos = {k: v[:, -1:, :, :h4] + self.lora_shift * scale[k] for k, v in batch.atmos_vars.items()}
        md = Metadata(batch.metadata.lat[:h4], batch.metadata.lon, batch.metadata.time, batch.metadata.atmos_levels)
        return Batch(surf, batch.static_vars, atmos, md)


def rollout(model, batch, steps):
    for _ in range(steps):
        pred = model.forward(batch)
        yield pred
        pad = lambda t, ax: torch.cat([t, t.narrow(ax, t.shape[ax] - 1, 1)], dim=ax)  # noqa: E731
        surf = {k: torch.cat([batch.surf_vars[k][:, 1:], pad(pred.surf_vars[k], -2)], dim=1) for k in pred.surf_vars}
        atmos = {k: torch.cat([batch.atmos_vars[k][:, 1:], pad(pred.atmos_vars[k], -2)], dim=1) for k in pred.atmos_vars}
        batch = Batch(surf, batch.static_vars, atmos, batch.metadata)


fake = types.ModuleType("aurora")
fake.Batch, fake.Metadata, fake.rollout = Batch, Metadata, rollout
sys.modules["aurora"] = fake

from aurora_earth_system_pipeline import pipeline as P  # noqa: E402
from aurora_earth_system_pipeline.metrics import persistence_only  # noqa: E402


def synthetic_window(n_steps, name, seed, trend=0.3):
    rng = np.random.default_rng(seed)
    lat = np.linspace(90, -90, 17)
    lon = np.arange(32) * (360 / 32)
    mid = {"2t": 280.0, "10u": 0.0, "10v": 0.0, "msl": 101000.0, "t": 250.0, "u": 0.0, "v": 0.0, "q": 0.005, "z": 50000.0}
    times = [f"2021-10-01T{6 * i:02d}:00:00" if 6 * i < 24 else f"2021-10-0{1 + (6 * i) // 24}T{(6 * i) % 24:02d}:00:00" for i in range(n_steps)]
    surf = {k: (mid[k] + trend * np.arange(n_steps)[:, None, None] * P.LOSS_SCALES[k] / 10 + rng.normal(0, 0.01 * P.LOSS_SCALES[k], (n_steps, 17, 32))).astype("float32") for k in P.SURF_VARS}
    atmos = {k: (mid[k] + trend * np.arange(n_steps)[:, None, None, None] * P.LOSS_SCALES[k] / 10 + rng.normal(0, 0.01 * P.LOSS_SCALES[k], (n_steps, 13, 17, 32))).astype("float32") for k in P.ATMOS_VARS}
    static = {"lsm": np.zeros((17, 32), "float32"), "z": np.zeros((17, 32), "float32"), "slt": np.ones((17, 32), "float32")}
    return {"name": name, "lat": lat, "lon": lon, "levels": list(P.LEVELS), "times": times, "surf": surf, "atmos": atmos, "static": static}


def standin_pipe():
    return P.AuroraPipeline(model=StandIn().eval(), device="cpu", weights_dir=Path("."), source="stand-in", use_lora=True)


# ---- P2 BYOD at the documented minimum (3 steps = the shape Section 4 writes) at notebook defaults ----
ORIGIN, ROLLOUT_STEPS, MAX_LEAD_STEPS = 1, 4, 4
p2 = {}
for n in (3, 4, 5, 6, 8):
    w = synthetic_window(n, f"byod-{n}", n)
    row = {"validate_inputs": "accepted"}
    try:
        P.validate_inputs(w)
    except ValueError as exc:
        row["validate_inputs"] = f"rejected: {exc}"
    try:
        persistence_only(w, max_lead_steps=MAX_LEAD_STEPS)
        row["section6_persistence_only"] = "ok"
    except ValueError as exc:
        row["section6_persistence_only"] = f"ValueError: {exc}"
    pipe = standin_pipe()
    try:
        pipe.evaluate(w, max_lead_steps=MAX_LEAD_STEPS)
        row["section6_evaluate"] = "ok"
    except ValueError as exc:
        row["section6_evaluate"] = f"ValueError: {exc}"
    new_origin = min(n - 1 - ROLLOUT_STEPS, 3)
    row["section9_NEW_ORIGIN"] = new_origin
    try:
        pipe.predict(w, origin=new_origin, steps=ROLLOUT_STEPS)
        row["section9_predict"] = "ok"
    except ValueError as exc:
        row["section9_predict"] = f"ValueError: {exc}"
    p2[n] = row
record("P2_byod_min_steps_at_defaults_STANDIN", p2)

# ---- P3 rerun-from-Section-4 state (BYOD instruction / optional experiments) --------------------------
train = [synthetic_window(8, "train-a", 1), synthetic_window(8, "train-b", 2)]
val, test = synthetic_window(8, "val", 3), synthetic_window(8, "test", 4)
pipe = standin_pipe()
first = {}
r = pipe.predict(test, origin=ORIGIN, steps=ROLLOUT_STEPS)
first["section5_adapted_flag"] = r["model"]["adapted"]
f1 = pipe.evaluate(test, max_lead_steps=MAX_LEAD_STEPS)
first["section6_frozen_mean_skill_6h"] = round(f1["summary"]["6h"]["mean_skill"], 6)
a1 = pipe.adapt(train, val, epochs=3, lr=1e-2)
first["lora_after_adapt"] = float(pipe.model.lora_shift)
second = {}
r2 = pipe.predict(test, origin=ORIGIN, steps=ROLLOUT_STEPS)
second["section5_adapted_flag"] = r2["model"]["adapted"]
f2 = pipe.evaluate(test, max_lead_steps=MAX_LEAD_STEPS)
second["section6_frozen_mean_skill_6h"] = round(f2["summary"]["6h"]["mean_skill"], 6)
second["lora_before_second_adapt"] = float(pipe.model.lora_shift)
a2 = pipe.adapt(train, val, epochs=3, lr=1e-2)
second["epoch0_note"] = a2["history"][0].get("note")
second["epoch0_val_loss_vs_first_run_epoch0"] = [a2["history"][0]["val_loss"], a1["history"][0]["val_loss"]]
record("P3_rerun_state_STANDIN", {"first_pass": first, "rerun_from_section4_same_pipe": second,
    "frozen_numbers_changed_on_rerun": first["section6_frozen_mean_skill_6h"] != second["section6_frozen_mean_skill_6h"]})

# ---- P4 adapt() source: no LoRA reset at entry -------------------------------------------------------
import inspect  # noqa: E402

src = inspect.getsource(P.AuroraPipeline.adapt)
record("P4_adapt_source", {"resets_lora_at_entry": any(s in src for s in ("zero_()", "reset_", "initial_state)\n        try")),
    "epoch0_note_is_literal": "frozen model (LoRA zero-initialised)" in src,
    "initial_state_used_only_in_except": src.count("initial_state") == 2})

# ---- manifest ----------------------------------------------------------------------------------------
files = ["tutorials/aurora_earth_system_colab.ipynb", "tutorials/README.md", "docs/release-verification.md", "README.md",
         "STATUS.md", "MODEL_CARD.md", "tools/build_notebook.py", "tools/notebook_template.py",
         "src/aurora_earth_system_pipeline/pipeline.py", "src/aurora_earth_system_pipeline/samples.py",
         "src/aurora_earth_system_pipeline/metrics.py"]
manifest = {f: hashlib.sha256((ROOT / f).read_bytes()).hexdigest() for f in files}
(Path(__file__).with_name("source_manifest.json")).write_text(json.dumps(manifest, indent=2), encoding="utf-8")
(Path(__file__).with_name("results.json")).write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")
print("written results.json and source_manifest.json")
